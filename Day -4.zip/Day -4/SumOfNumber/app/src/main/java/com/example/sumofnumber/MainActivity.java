package com.example.sumofnumber;

import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText value1,value2;
    TextView sum;
    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        value1 = findViewById(R.id.value1);
        value2 = findViewById(R.id.value2);
        sum = findViewById(R.id.sum);
        btn = findViewById(R.id.btn);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String number1 = value1.getText().toString();
                String number2 = value2.getText().toString();


                int a =  Integer.parseInt(number1);
                int b =  Integer.parseInt(number2);

                int Add = a+b ;

                sum.setText("Sum of Two nummber is"  +Add);
            }
        });





    }


}