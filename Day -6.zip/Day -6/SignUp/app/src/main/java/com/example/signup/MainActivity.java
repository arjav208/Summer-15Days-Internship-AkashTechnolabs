package com.example.signup;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;

import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button Signup;
    EditText user_name, user_email, user_phone, user_password, user_Repassword;

    RadioGroup genderRadioGroup, hobbyRadioGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (android.os.Build.VERSION.SDK_INT >= 21) {
            Window window = this.getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(this.getResources().getColor(R.color.black));
        }

        Signup = findViewById(R.id.Signup);
        user_name = findViewById(R.id.user_name);
        user_email = findViewById(R.id.user_email);
        user_phone = findViewById(R.id.user_mobile);
        user_password = findViewById(R.id.user_password);

        genderRadioGroup = (RadioGroup) findViewById(R.id.genderRadioGroup);
        hobbyRadioGroup = (RadioGroup) findViewById(R.id.hobbyRadioGroup);

        Signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, HomePage.class);

                Bundle b = new Bundle();
                b.putString("user_name", user_name.getText().toString());
                b.putString("user_email", user_email.getText().toString());
                b.putString("user_phone", user_phone.getText().toString());
                b.putString("user_password", user_password.getText().toString());


                int gender = genderRadioGroup.getCheckedRadioButtonId();
                RadioButton radioButton = (RadioButton) findViewById(gender);
                b.putString("gender", radioButton.getText().toString());
                intent.putExtras(b);
                
                int hobby = hobbyRadioGroup.getCheckedRadioButtonId();
                RadioButton radioButton2 = (RadioButton) findViewById(hobby);
                b.putString("hobby", radioButton2.getText().toString());
                intent.putExtras(b);

//                Toast.makeText(MainActivity.this,""+radioButton2.getText().toString(),Toast.LENGTH_SHORT).show();
                startActivity(intent);
            }
        });

    }


}