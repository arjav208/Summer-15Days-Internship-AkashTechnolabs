package com.example.signup;

import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;

public class HomePage extends AppCompatActivity {

    TextView user_name, user_email, user_phone, user_password,gender,hooby;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if (android.os.Build.VERSION.SDK_INT >= 21) {
            Window window = this.getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(this.getResources().getColor(R.color.black));
        }

        Bundle b = getIntent().getExtras();

        user_name = findViewById(R.id.user_name);
        user_email = findViewById(R.id.user_email);
        user_phone = findViewById(R.id.user_mobile);
        user_password = findViewById(R.id.user_password);
        gender = findViewById(R.id.gender);
        hooby = findViewById(R.id.hooby);


        user_name.setText(b.getCharSequence("user_name"));
        user_email.setText(b.getCharSequence("user_email"));
        user_phone.setText(b.getCharSequence("user_phone"));
        user_password.setText(b.getCharSequence("user_password"));
        gender.setText(b.getCharSequence("gender"));
        hooby.setText(b.getCharSequence("hobby"));



    }
}