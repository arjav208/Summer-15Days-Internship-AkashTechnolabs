package com.example.sharedprefrance;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.TextView;

public class Home extends AppCompatActivity {

    TextView user_name, user_email, user_phone, user_password;

    public static final String my = "user_data";
    public static final String name = "user_name";
    public static final String email = "user_mail";
    public static final String password = "user_pass";
    public static final String mobile = "user_mob";

    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        user_name = findViewById(R.id.user_name);
        user_email = findViewById(R.id.user_email);
        user_phone = findViewById(R.id.user_mobile);
        user_password = findViewById(R.id.user_password);


        sharedPreferences = getSharedPreferences(my, Context.MODE_PRIVATE);

        user_name.setText(sharedPreferences.getString(name, ""));
        user_email.setText(sharedPreferences.getString(email, ""));
        user_phone.setText(sharedPreferences.getString(password, ""));
        user_password.setText(sharedPreferences.getString(mobile, ""));
    }
}