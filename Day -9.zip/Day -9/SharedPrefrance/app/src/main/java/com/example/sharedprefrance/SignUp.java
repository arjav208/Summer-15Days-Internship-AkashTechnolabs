package com.example.sharedprefrance;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SignUp extends AppCompatActivity {

    EditText reg_name,reg_email,reg_psw,reg_rpsw,reg_mobile;
    Button signup;
    public static final String my = "user_data";
    public static final String name = "user_name";
    public static final String email = "user_mail";
    public static final String password = "user_pass";
    public static final String mobile = "user_mob";

    SharedPreferences sharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if (android.os.Build.VERSION.SDK_INT >= 21) {
            Window window = this.getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(this.getResources().getColor(R.color.black));
        }

        reg_name = findViewById(R.id.reg_name);
        reg_email = findViewById(R.id.reg_mail);
        reg_mobile = findViewById(R.id.reg_phone);
        reg_psw = findViewById(R.id.psw);
        reg_rpsw = findViewById(R.id.reg_psw);
        signup = findViewById(R.id.sign_up);





        sharedPreferences = getSharedPreferences(my, Context.MODE_PRIVATE);

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String f_name = reg_name.getText().toString();
                String f_email = reg_email.getText().toString();
                String f_mobile = reg_mobile.getText().toString();
                String f_psw = reg_psw.getText().toString();
                String f_fpsw = reg_rpsw.getText().toString();

                if (f_name.equals("")) {
                    reg_name.setError("enter name");
                } else if (f_email.equals("")) {
                    reg_email.setError("enter mail");
                } else if (f_mobile.equals("")) {
                    reg_mobile.setError("enter mobile number");
                } else if (f_psw.equals("")) {
                    reg_psw.setError("enter password");
                } else if (f_fpsw.equals("")) {
                    reg_rpsw.setError("enter re-password");
                } else {


                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString(name, f_name);
                    editor.putString(email, f_email);
                    editor.putString(password, f_psw);
                    editor.putString(mobile, f_mobile);
                    editor.commit();

                    if (f_email.equals("")) {
                        Toast.makeText(SignUp.this, "enter your mail", Toast.LENGTH_SHORT).show();
                    } else {

                        if (f_psw.equals(f_fpsw)) {
                            Intent i = new Intent(SignUp.this, MainActivity.class);
                            startActivity(i);
                        } else {
                            Toast.makeText(SignUp.this, "password not match", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
        });
    }
}