package com.example.sharedprefrance;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;

import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText user_id,user_psw;
    TextView creat_account;
    Button login_btn;

    public static final String my = "user_data";
    public static final String name = "user_name";
    public static final String email = "user_mail";
    public static final String password = "user_pass";

    SharedPreferences sharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if (android.os.Build.VERSION.SDK_INT >= 21) {
            Window window = this.getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(this.getResources().getColor(R.color.black));
        }

        user_id = findViewById(R.id.user_id);
        user_psw = findViewById(R.id.user_psw);
        login_btn = findViewById(R.id.login_btn);
        creat_account = findViewById(R.id.creat_account);

        sharedPreferences = getSharedPreferences( my, Context.MODE_PRIVATE);

        creat_account.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this,SignUp.class);
                startActivity(i);

            }
        });

        login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String s_id = sharedPreferences.getString(email,"");
                String s_psw = sharedPreferences.getString(password,"");

                String u_id = user_id.getText().toString();
                String u_pw = user_psw.getText().toString();

                if (u_id.equals("")){
                    user_id.setError("enter user id");
                }else if(u_pw.equals("")){
                    user_psw.setError("enter password");
                }else {

                    if (s_id.equals(user_id.getText().toString())) {

                        if (s_psw.equals(user_psw.getText().toString())) {

                            Intent i = new Intent(MainActivity.this, Home.class);
                            startActivity(i);
                        } else {
                            Toast.makeText(MainActivity.this, "password not match", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(MainActivity.this, "enter valid username", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });




    }


}